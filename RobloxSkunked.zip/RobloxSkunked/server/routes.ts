import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertScriptSchema, 
  insertActivitySchema,
  insertAdminLogSchema
} from "@shared/schema";

// Extend the Express Request type to include session
declare module "express" {
  interface Request {
    session?: {
      userId?: number;
      [key: string]: any;
    };
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Affiliation link redirect route
  app.get("/a/:username", async (req: Request, res: Response) => {
    const { username } = req.params;
    const user = await storage.getUserByUsername(username);
    
    if (!user) {
      return res.status(404).send("User not found");
    }
    
    // In a real app, you might want to track this referral in analytics
    // For now, just redirect to the main page
    return res.redirect("/");
  });
  // Users routes
  app.post("/api/users", async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const existingUser = await storage.getUserByUsername(userData.username);
      
      if (existingUser) {
        return res.status(409).json({ message: "Username already exists" });
      }
      
      // Check if the key is valid
      if (!userData.password || userData.password.length < 5) {
        return res.status(400).json({ message: "Invalid whitelist key" });
      }
      
      const user = await storage.createUser(userData);
      
      // Set user in session
      if (req.session) {
        req.session.userId = user.id;
      }
      
      return res.status(201).json({ 
        id: user.id, 
        username: user.username, 
        plan: user.plan,
        role: user.role
      });
    } catch (error) {
      return res.status(400).json({ message: "Invalid user data" });
    }
  });
  
  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const { username, key } = req.body;
      
      if (!username || !key) {
        return res.status(400).json({ message: "Username and key are required" });
      }
      
      // Find user by username
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(401).json({ message: "Invalid username or key" });
      }
      
      // Verify key (password)
      if (user.password !== key) {
        return res.status(401).json({ message: "Invalid username or key" });
      }
      
      // Set user in session
      if (req.session) {
        req.session.userId = user.id;
      }
      
      return res.json({
        id: user.id,
        username: user.username,
        plan: user.plan,
        role: user.role,
        createdAt: user.createdAt
      });
    } catch (error) {
      return res.status(500).json({ message: "Login failed" });
    }
  });
  
  app.get("/api/users/current", async (req: Request, res: Response) => {
    // Check if user is logged in via session
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    // Get user from storage using session userId
    const user = await storage.getUser(req.session.userId);
    
    if (!user) {
      // Clear invalid session
      if (req.session) {
        req.session.userId = undefined;
      }
      return res.status(401).json({ message: "User not found" });
    }
    
    return res.json({
      id: user.id,
      username: user.username,
      plan: user.plan,
      role: user.role,
      createdAt: user.createdAt
    });
  });
  
  // Logout endpoint
  app.post("/api/auth/logout", (req: Request, res: Response) => {
    if (req.session) {
      req.session.userId = undefined;
    }
    return res.json({ success: true });
  });
  
  // Games routes
  app.get("/api/games", async (_req: Request, res: Response) => {
    const games = await storage.getGames();
    return res.json(games);
  });
  
  app.get("/api/games/popular", async (_req: Request, res: Response) => {
    const games = await storage.getPopularGames();
    return res.json(games);
  });
  
  app.get("/api/games/:id", async (req: Request, res: Response) => {
    const gameId = parseInt(req.params.id);
    
    if (isNaN(gameId)) {
      return res.status(400).json({ message: "Invalid game ID" });
    }
    
    const game = await storage.getGame(gameId);
    
    if (!game) {
      return res.status(404).json({ message: "Game not found" });
    }
    
    return res.json(game);
  });
  
  // Scripts routes
  app.get("/api/scripts", async (req: Request, res: Response) => {
    // In a real app, this would use the session to get the current user
    const user = await storage.getUserByUsername("SkunkedUser");
    
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    const scripts = await storage.getScripts(user.id);
    return res.json(scripts);
  });
  
  app.post("/api/scripts", async (req: Request, res: Response) => {
    try {
      const user = await storage.getUserByUsername("SkunkedUser");
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const scriptData = insertScriptSchema.parse({
        ...req.body,
        userId: user.id
      });
      
      const script = await storage.createScript(scriptData);
      
      // Record the activity
      await storage.createActivity({
        userId: user.id,
        type: "script_saved",
        details: `Saved new script "${script.name}"`,
        gameId: script.gameId
      });
      
      return res.status(201).json(script);
    } catch (error) {
      return res.status(400).json({ message: "Invalid script data" });
    }
  });
  
  // Activities routes
  app.get("/api/activities", async (req: Request, res: Response) => {
    const user = await storage.getUserByUsername("SkunkedUser");
    
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    const activities = await storage.getUserActivities(user.id);
    return res.json(activities);
  });
  
  // User Stats routes
  app.get("/api/user-stats", async (req: Request, res: Response) => {
    const user = await storage.getUserByUsername("SkunkedUser");
    
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    const stats = await storage.getUserStats(user.id);
    
    if (!stats) {
      return res.status(404).json({ message: "User stats not found" });
    }
    
    return res.json(stats);
  });
  
  // Execute script route (mock)
  app.post("/api/execute-script", async (req: Request, res: Response) => {
    try {
      const { script, gameId } = req.body;
      
      if (!script) {
        return res.status(400).json({ message: "Script content is required" });
      }
      
      const user = await storage.getUserByUsername("SkunkedUser");
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Update user stats
      const stats = await storage.getUserStats(user.id);
      
      if (stats) {
        const currentExecutions = stats.scriptsExecuted || 0;
        await storage.updateUserStats(user.id, {
          scriptsExecuted: currentExecutions + 1
        });
      }
      
      // Record the activity
      await storage.createActivity({
        userId: user.id,
        type: "script_executed",
        details: "Executed script in game",
        gameId: gameId || null
      });
      
      return res.json({ 
        success: true, 
        message: "Script executed successfully",
        output: [
          "Connecting to game server...",
          "Connection established",
          "Serverside ready",
          "Executing script...",
          "Activating admin commands...",
          "Admin commands activated!"
        ]
      });
    } catch (error) {
      return res.status(500).json({ message: "Failed to execute script" });
    }
  });

  // Admin routes
  // Middleware to check if user is an admin
  const isAdmin = async (req: Request, res: Response, next: NextFunction) => {
    // Check if user is logged in via session
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    // Get user from storage
    const user = await storage.getUser(req.session.userId);
    
    if (!user) {
      return res.status(401).json({ message: "User not found" });
    }
    
    // Check if user is an admin or superadmin
    if (user.role !== 'admin' && user.role !== 'superadmin') {
      return res.status(403).json({ message: "Unauthorized. Admin role required." });
    }
    
    // User is admin, proceed to the route
    next();
  };

  // Get all users (admin only)
  app.get("/api/admin/users", isAdmin, async (req: Request, res: Response) => {
    try {
      const users = await storage.getAllUsers();
      return res.json(users);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  // Blacklist a user (admin only)
  app.post("/api/admin/users/:id/blacklist", isAdmin, async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      const { reason, ip } = req.body;
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      if (!reason) {
        return res.status(400).json({ message: "Reason is required" });
      }
      
      const adminId = req.session!.userId!;
      const updatedUser = await storage.blacklistUser(userId, adminId, reason, ip);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      return res.json({ 
        success: true, 
        message: "User blacklisted",
        user: updatedUser 
      });
    } catch (error) {
      return res.status(500).json({ message: "Failed to blacklist user" });
    }
  });

  // Whitelist a user (admin only)
  app.post("/api/admin/users/:id/whitelist", isAdmin, async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      const { reason } = req.body;
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      if (!reason) {
        return res.status(400).json({ message: "Reason is required" });
      }
      
      const adminId = req.session!.userId!;
      const updatedUser = await storage.whitelistUser(userId, adminId, reason);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      return res.json({ 
        success: true, 
        message: "User whitelisted",
        user: updatedUser 
      });
    } catch (error) {
      return res.status(500).json({ message: "Failed to whitelist user" });
    }
  });

  // Change user role (admin only)
  app.post("/api/admin/users/:id/role", isAdmin, async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      const { role } = req.body;
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      if (!role || !['user', 'admin', 'superadmin'].includes(role)) {
        return res.status(400).json({ message: "Valid role is required" });
      }
      
      const adminId = req.session!.userId!;
      const updatedUser = await storage.changeUserRole(userId, adminId, role);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      return res.json({ 
        success: true, 
        message: "User role updated",
        user: updatedUser 
      });
    } catch (error) {
      return res.status(500).json({ message: "Failed to update user role" });
    }
  });

  // Get admin logs (admin only)
  app.get("/api/admin/logs", isAdmin, async (req: Request, res: Response) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const logs = await storage.getAdminLogs(limit);
      return res.json(logs);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch admin logs" });
    }
  });

  // Get logs by admin (admin only)
  app.get("/api/admin/logs/by-admin/:adminId?", isAdmin, async (req: Request, res: Response) => {
    try {
      // If adminId is not provided in the URL, use the current user's ID
      let adminId = req.params.adminId ? parseInt(req.params.adminId) : req.session!.userId!;
      
      if (isNaN(adminId)) {
        return res.status(400).json({ message: "Invalid admin ID" });
      }
      
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const logs = await storage.getAdminLogsByAdmin(adminId, limit);
      
      return res.json(logs);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch admin logs" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
