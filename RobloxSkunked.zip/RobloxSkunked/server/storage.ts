import { 
  users, type User, type InsertUser,
  games, type Game, type InsertGame,
  scripts, type Script, type InsertScript,
  activities, type Activity, type InsertActivity,
  userStats, type UserStats, type InsertUserStats,
  adminLogs, type AdminLog, type InsertAdminLog
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  
  // Game operations
  getGames(): Promise<Game[]>;
  getGame(id: number): Promise<Game | undefined>;
  getPopularGames(limit?: number): Promise<Game[]>;
  createGame(game: InsertGame): Promise<Game>;
  
  // Script operations
  getScripts(userId: number): Promise<Script[]>;
  getScript(id: number): Promise<Script | undefined>;
  createScript(script: InsertScript): Promise<Script>;
  
  // Activity operations
  getUserActivities(userId: number, limit?: number): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;
  
  // UserStats operations
  getUserStats(userId: number): Promise<UserStats | undefined>;
  createUserStats(stats: InsertUserStats): Promise<UserStats>;
  updateUserStats(userId: number, stats: Partial<InsertUserStats>): Promise<UserStats | undefined>;
  
  // Admin operations
  createAdminLog(log: InsertAdminLog): Promise<AdminLog>;
  getAdminLogs(limit?: number): Promise<AdminLog[]>;
  getAdminLogsByAdmin(adminId: number, limit?: number): Promise<AdminLog[]>;
  blacklistUser(userId: number, adminId: number, reason: string, ip?: string): Promise<User | undefined>;
  whitelistUser(userId: number, adminId: number, reason: string): Promise<User | undefined>;
  changeUserRole(userId: number, adminId: number, newRole: string): Promise<User | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private games: Map<number, Game>;
  private scripts: Map<number, Script>;
  private activities: Map<number, Activity>;
  private userStats: Map<number, UserStats>;
  private adminLogs: Map<number, AdminLog>;
  
  private userIdCounter: number;
  private gameIdCounter: number;
  private scriptIdCounter: number;
  private activityIdCounter: number;
  private userStatsIdCounter: number;
  private adminLogIdCounter: number;

  constructor() {
    this.users = new Map();
    this.games = new Map();
    this.scripts = new Map();
    this.activities = new Map();
    this.userStats = new Map();
    this.adminLogs = new Map();
    
    this.userIdCounter = 1;
    this.gameIdCounter = 1;
    this.scriptIdCounter = 1;
    this.activityIdCounter = 1;
    this.userStatsIdCounter = 1;
    this.adminLogIdCounter = 1;
    
    // Seed some initial games
    this.seedGames();
    this.seedScripts();
  }

  private seedGames() {
    const defaultGames: InsertGame[] = [
      {
        name: "Brookhaven",
        description: "Roleplaying game",
        genre: "Roleplay",
        imageUrl: "https://imagedelivery.net/95_mmzfqHEMHzYp4CX8eSg/6ccf034c-ec73-412e-6e02-7f68c178ca00/public",
        activePlayers: 125000,
        isPopular: true,
        isSupported: true
      },
      {
        name: "Adopt Me",
        description: "Pet simulation game",
        genre: "Pet Simulation",
        imageUrl: "https://imagedelivery.net/95_mmzfqHEMHzYp4CX8eSg/a5f897ad-b107-417a-ccf5-1fb0f484e300/public",
        activePlayers: 92000,
        isPopular: true,
        isSupported: true
      },
      {
        name: "Blox Fruits",
        description: "Adventure game",
        genre: "Adventure",
        imageUrl: "https://imagedelivery.net/95_mmzfqHEMHzYp4CX8eSg/7ae9c0f3-a36f-4a56-7f53-e50e5f42bf00/public",
        activePlayers: 78000,
        isPopular: true,
        isSupported: true
      },
      {
        name: "Murder Mystery 2",
        description: "Mystery game",
        genre: "Mystery",
        imageUrl: "https://imagedelivery.net/95_mmzfqHEMHzYp4CX8eSg/d7a3cce1-fc25-4f79-c233-16f248f06900/public",
        activePlayers: 54000,
        isPopular: false,
        isSupported: false
      },
      {
        name: "Jailbreak",
        description: "Cops & Robbers game",
        genre: "Cops & Robbers",
        imageUrl: "https://imagedelivery.net/95_mmzfqHEMHzYp4CX8eSg/7f8a1143-5cf2-46da-dcdb-dd6a83bed000/public",
        activePlayers: 42000,
        isPopular: false,
        isSupported: true
      }
    ];
    
    defaultGames.forEach(game => this.createGame(game));
  }
  
  private seedScripts() {
    const defaultScripts: Partial<InsertScript>[] = [
      {
        name: "Admin Commands",
        content: "-- Admin Commands script\nprint('Admin Commands loaded')",
        isUniversal: true
      },
      {
        name: "Teleport Script",
        content: "-- Teleport script for Brookhaven\nprint('Teleport script loaded')",
        gameId: 1
      },
      {
        name: "ESP Script",
        content: "-- Universal ESP script\nprint('ESP script loaded')",
        isUniversal: true
      },
      {
        name: "Infinite Money",
        content: "-- Infinite Money for Adopt Me\nprint('Infinite Money script loaded')",
        gameId: 2
      }
    ];
    
    // These scripts don't have a user yet, so we'll add them later when users are created
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const createdAt = new Date();
    
    // Check if username is "fredo" (case insensitive) to set as admin
    const isAdmin = insertUser.username.toLowerCase() === "fredo";
    
    const user: User = { 
      id, 
      username: insertUser.username,
      password: insertUser.password,
      plan: insertUser.plan || "Free",
      role: isAdmin ? "admin" : "user",  // Make 'fredo' an admin
      isBlacklisted: false,
      ip: null,
      country: null,
      hwid: null,
      lastLogin: null,
      createdAt 
    };
    this.users.set(id, user);
    
    // Create default stats for the user
    await this.createUserStats({
      userId: id,
      scriptsExecuted: 0,
      gamesPlayed: 0,
      subscriptionDays: 30
    });
    
    if (isAdmin) {
      console.log(`Created admin user: ${insertUser.username}`);
    }
    
    return user;
  }
  
  // Game operations
  async getGames(): Promise<Game[]> {
    return Array.from(this.games.values());
  }
  
  async getGame(id: number): Promise<Game | undefined> {
    return this.games.get(id);
  }
  
  async getPopularGames(limit: number = 3): Promise<Game[]> {
    return Array.from(this.games.values())
      .filter(game => game.isPopular)
      .slice(0, limit);
  }
  
  async createGame(insertGame: InsertGame): Promise<Game> {
    const id = this.gameIdCounter++;
    
    const game: Game = { 
      id, 
      name: insertGame.name,
      description: insertGame.description,
      genre: insertGame.genre,
      imageUrl: insertGame.imageUrl,
      activePlayers: insertGame.activePlayers || 0,
      isPopular: insertGame.isPopular || false,
      isSupported: insertGame.isSupported || true
    };
    
    this.games.set(id, game);
    return game;
  }
  
  // Script operations
  async getScripts(userId: number): Promise<Script[]> {
    return Array.from(this.scripts.values())
      .filter(script => script.userId === userId);
  }
  
  async getScript(id: number): Promise<Script | undefined> {
    return this.scripts.get(id);
  }
  
  async createScript(insertScript: InsertScript): Promise<Script> {
    const id = this.scriptIdCounter++;
    const createdAt = new Date();
    
    const script: Script = { 
      id, 
      name: insertScript.name,
      content: insertScript.content,
      userId: insertScript.userId || null,
      gameId: insertScript.gameId || null,
      isUniversal: insertScript.isUniversal || false,
      createdAt
    };
    
    this.scripts.set(id, script);
    return script;
  }
  
  // Activity operations
  async getUserActivities(userId: number, limit: number = 10): Promise<Activity[]> {
    return Array.from(this.activities.values())
      .filter(activity => activity.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }
  
  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const id = this.activityIdCounter++;
    const createdAt = new Date();
    
    const activity: Activity = { 
      id, 
      type: insertActivity.type,
      details: insertActivity.details,
      userId: insertActivity.userId || null,
      gameId: insertActivity.gameId || null,
      createdAt
    };
    
    this.activities.set(id, activity);
    return activity;
  }
  
  // UserStats operations
  async getUserStats(userId: number): Promise<UserStats | undefined> {
    return Array.from(this.userStats.values())
      .find(stats => stats.userId === userId);
  }
  
  async createUserStats(insertUserStats: InsertUserStats): Promise<UserStats> {
    const id = this.userStatsIdCounter++;
    
    const userStats: UserStats = { 
      id, 
      userId: insertUserStats.userId || null,
      scriptsExecuted: insertUserStats.scriptsExecuted || 0,
      gamesPlayed: insertUserStats.gamesPlayed || 0,
      subscriptionDays: insertUserStats.subscriptionDays || 0
    };
    
    this.userStats.set(id, userStats);
    return userStats;
  }
  
  async updateUserStats(userId: number, updates: Partial<InsertUserStats>): Promise<UserStats | undefined> {
    const stats = await this.getUserStats(userId);
    
    if (!stats) return undefined;
    
    const updatedStats: UserStats = {
      ...stats,
      ...updates
    };
    
    this.userStats.set(stats.id, updatedStats);
    return updatedStats;
  }

  // Additional User operations
  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const user = await this.getUser(id);
    
    if (!user) return undefined;
    
    const updatedUser: User = {
      ...user,
      ...updates
    };
    
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // Admin operations
  async createAdminLog(log: InsertAdminLog): Promise<AdminLog> {
    const id = this.adminLogIdCounter++;
    const createdAt = new Date();
    
    const adminLog: AdminLog = { 
      id,
      adminId: log.adminId,
      action: log.action,
      targetUserId: log.targetUserId || null,
      details: log.details,
      ip: log.ip || null,
      createdAt
    };
    
    this.adminLogs.set(id, adminLog);
    return adminLog;
  }

  async getAdminLogs(limit: number = 50): Promise<AdminLog[]> {
    return Array.from(this.adminLogs.values())
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, limit);
  }

  async getAdminLogsByAdmin(adminId: number, limit: number = 50): Promise<AdminLog[]> {
    return Array.from(this.adminLogs.values())
      .filter(log => log.adminId === adminId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, limit);
  }

  async blacklistUser(userId: number, adminId: number, reason: string, ip?: string): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;

    // Update user to blacklisted status
    const updatedUser = await this.updateUser(userId, { 
      isBlacklisted: true,
      ip: ip || user.ip
    });

    // Create admin log
    await this.createAdminLog({
      adminId,
      action: "blacklist",
      targetUserId: userId,
      details: reason,
      ip
    });

    return updatedUser;
  }

  async whitelistUser(userId: number, adminId: number, reason: string): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;

    // Update user to whitelisted status
    const updatedUser = await this.updateUser(userId, { 
      isBlacklisted: false
    });

    // Create admin log
    await this.createAdminLog({
      adminId,
      action: "whitelist",
      targetUserId: userId,
      details: reason
    });

    return updatedUser;
  }

  async changeUserRole(userId: number, adminId: number, newRole: string): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;

    // Update user role
    const updatedUser = await this.updateUser(userId, { 
      role: newRole
    });

    // Create admin log
    await this.createAdminLog({
      adminId,
      action: "role_change",
      targetUserId: userId,
      details: `Changed role from ${user.role} to ${newRole}`
    });

    return updatedUser;
  }
}

export const storage = new MemStorage();
