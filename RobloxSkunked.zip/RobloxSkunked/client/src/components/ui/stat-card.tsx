import { ReactNode } from "react";
import { Card, CardContent } from "@/components/ui/card";

interface StatCardProps {
  icon: ReactNode;
  label: string;
  value: string | number;
  iconColor?: string;
  iconBgColor?: string;
}

export function StatCard({ 
  icon, 
  label, 
  value, 
  iconColor = "text-primary", 
  iconBgColor = "bg-primary/20" 
}: StatCardProps) {
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex items-center">
          <div className={`h-10 w-10 rounded-md ${iconBgColor} flex items-center justify-center mr-3`}>
            <div className={iconColor}>{icon}</div>
          </div>
          <div>
            <p className="text-muted-foreground text-sm">{label}</p>
            <p className="text-xl font-semibold">{value}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
