import { Game } from "@/lib/types";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { User } from "lucide-react";

interface GameCardProps {
  game: Game;
  variant?: "featured" | "small";
  onJoin?: (gameId: number) => void;
  lastPlayed?: string;
}

export function GameCard({ game, variant = "featured", onJoin, lastPlayed }: GameCardProps) {
  const handleJoin = () => {
    if (onJoin) {
      onJoin(game.id);
    }
  };
  
  if (variant === "small") {
    return (
      <Card className="overflow-hidden">
        <div className="h-28 bg-muted">
          <img 
            src={game.imageUrl} 
            className="w-full h-full object-cover" 
            alt={game.name} 
          />
        </div>
        <div className="p-3">
          <h3 className="font-medium text-sm">{game.name}</h3>
          <div className="flex items-center justify-between mt-2">
            <span className="text-xs text-muted-foreground">{lastPlayed || "Recently"}</span>
            <Button 
              variant="outline" 
              size="sm" 
              className="h-7 text-xs"
              onClick={handleJoin}
            >
              Join
            </Button>
          </div>
        </div>
      </Card>
    );
  }
  
  return (
    <Card className="overflow-hidden">
      <div className="h-40 bg-muted relative">
        <img 
          src={game.imageUrl} 
          className="w-full h-full object-cover" 
          alt={game.name} 
        />
        {game.isPopular && (
          <Badge className="absolute top-2 right-2">
            Popular
          </Badge>
        )}
      </div>
      <div className="p-4">
        <h3 className="font-semibold mb-1">{game.name}</h3>
        <p className="text-muted-foreground text-sm mb-3">{game.description}</p>
        <div className="flex items-center justify-between">
          <span className="text-xs flex items-center text-muted-foreground">
            <User className="mr-1 h-3 w-3" /> {(game.activePlayers / 1000).toFixed(0)}K Active
          </span>
          <Button size="sm" onClick={handleJoin}>Join</Button>
        </div>
      </div>
    </Card>
  );
}
