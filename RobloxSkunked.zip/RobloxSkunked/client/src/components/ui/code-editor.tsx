import { useRef, useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Trash2, Copy, Save, Play, Paperclip, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import Prism from 'prismjs';
import 'prismjs/components/prism-lua';
import 'prismjs/themes/prism-tomorrow.css';

interface CodeEditorProps {
  defaultValue?: string;
  onExecute: (code: string) => void;
  onSave?: (code: string) => void;
}

export function CodeEditor({ defaultValue = "", onExecute, onSave }: CodeEditorProps) {
  const [code, setCode] = useState(defaultValue || `-- Enter your Lua script here
      
local Players = game:GetService('Players')
local LocalPlayer = Players.LocalPlayer

-- Basic serverside script example
local function giveAdminCommands()
   print('Activating admin commands...')
   -- Serverside code would execute here
   return true
end

-- Call the function
local success = giveAdminCommands()
if success then
   print('Admin commands activated!')
else
   warn('Failed to activate admin commands!')
end`);
  
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const { toast } = useToast();
  
  const handleClearCode = () => {
    if (confirm("Are you sure you want to clear the editor?")) {
      setCode("");
      toast({
        title: "Editor cleared",
        description: "All code has been removed from the editor."
      });
    }
  };
  
  const handleCopyCode = () => {
    navigator.clipboard.writeText(code);
    toast({
      title: "Copied to clipboard",
      description: "Script code has been copied to clipboard."
    });
  };
  
  const handleSaveCode = () => {
    if (onSave) {
      onSave(code);
    }
    toast({
      title: "Script saved",
      description: "Your script has been saved successfully."
    });
  };
  
  const handleExecuteCode = () => {
    onExecute(code);
  };
  
  // Initialize and update Prism.js highlighting
  useEffect(() => {
    // Initialize Prism.js when component mounts
    Prism.highlightAll();
  }, []);
  
  // Update highlighting when code changes
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
      textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
      
      // Highlight after a short delay to ensure DOM is updated
      setTimeout(() => {
        Prism.highlightAll();
      }, 0);
    }
  }, [code]);
  
  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle>Editor</CardTitle>
            <div className="flex space-x-2">
              <Button 
                variant="outline" 
                size="icon" 
                title="Clear" 
                onClick={handleClearCode}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
              <Button 
                variant="outline" 
                size="icon" 
                title="Copy" 
                onClick={handleCopyCode}
              >
                <Copy className="h-4 w-4" />
              </Button>
              <Button 
                variant="outline" 
                size="icon" 
                title="Save" 
                onClick={handleSaveCode}
              >
                <Save className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="relative overflow-hidden rounded-md">
            <div className="bg-[#0D1117] rounded-md">
              <div className="flex text-xs border-b border-gray-700">
                <button className="py-2 px-4 bg-[#161B22] text-white border-r border-gray-700">Script 1</button>
                <button className="py-2 px-4 text-gray-400 hover:text-white">+ New Script</button>
              </div>
              <div className="relative">
                <pre className="w-full h-64 min-h-[300px] overflow-auto language-lua p-4" style={{margin: 0, background: '#0D1117', lineHeight: 1.5}}>
                  <code className="language-lua">{code}</code>
                </pre>
                <textarea 
                  ref={textareaRef}
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  className="absolute top-0 left-0 w-full bg-transparent text-transparent caret-white p-4 h-64 min-h-[300px] font-mono text-sm focus:outline-none resize-y"
                  spellCheck={false}
                  style={{
                    zIndex: 10,
                    caretColor: 'white',
                    whiteSpace: 'pre',
                    fontFamily: 'monospace'
                  }}
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <div className="flex flex-col sm:flex-row gap-3">
        <Button 
          onClick={handleExecuteCode}
          className="flex items-center"
        >
          <Play className="mr-2 h-4 w-4" /> Execute
        </Button>
        <Button 
          variant="secondary"
          className="flex items-center"
        >
          <Paperclip className="mr-2 h-4 w-4" /> Attach
        </Button>
        <Button 
          variant="destructive"
          className="flex items-center"
        >
          <X className="mr-2 h-4 w-4" /> Kill Script
        </Button>
      </div>
    </div>
  );
}
