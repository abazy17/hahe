import { Link, useLocation } from "wouter";
import { User } from "@/lib/types";
import { useAuth } from "@/lib/authContext";
import { 
  UserCircle, 
  Gamepad2, 
  Terminal, 
  Settings, 
  LogOut,
  Code,
  ShieldAlert
} from "lucide-react";

interface SidebarProps {
  user: User | null;
}

export function Sidebar({ user }: SidebarProps) {
  const [location] = useLocation();
  const { logout, isAdmin } = useAuth();
  
  const navItems = [
    { 
      name: "Profile", 
      path: "/profile", 
      icon: <UserCircle className="mr-3 h-5 w-5" /> 
    },
    { 
      name: "Games", 
      path: "/games", 
      icon: <Gamepad2 className="mr-3 h-5 w-5" /> 
    },
    { 
      name: "Executor", 
      path: "/executor", 
      icon: <Terminal className="mr-3 h-5 w-5" /> 
    },
    { 
      name: "Settings", 
      path: "/settings", 
      icon: <Settings className="mr-3 h-5 w-5" /> 
    },
    ...(isAdmin ? [{ 
      name: "Admin", 
      path: "/admin", 
      icon: <ShieldAlert className="mr-3 h-5 w-5" /> 
    }] : [])
  ];
  
  const getUserInitials = (username?: string) => {
    if (!username) return "SK";
    
    const names = username.split(" ");
    if (names.length === 1) {
      return username.substring(0, 2).toUpperCase();
    }
    
    return `${names[0].charAt(0)}${names[1].charAt(0)}`.toUpperCase();
  };
  
  const handleLogout = () => {
    logout();
  };
  
  return (
    <div className="hidden md:flex md:w-64 flex-col bg-card border-r border-border">
      <div className="p-4 flex items-center border-b border-border">
        <div className="h-8 w-8 rounded-md bg-primary flex items-center justify-center mr-3">
          <Code className="text-primary-foreground h-5 w-5" />
        </div>
        <h1 className="text-xl font-bold">Skunked</h1>
      </div>

      <nav className="flex-1 pt-4 pb-4">
        <div className="space-y-1 px-2">
          {navItems.map((item) => (
            <Link 
              key={item.path} 
              href={item.path}
            >
              <a 
                className={`flex items-center px-3 py-2 w-full rounded-md transition-all ${
                  location === item.path 
                    ? "bg-primary text-primary-foreground font-medium" 
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
              >
                {item.icon}
                <span>{item.name}</span>
              </a>
            </Link>
          ))}
        </div>
      </nav>

      <div className="p-4 border-t border-border">
        <div className="flex items-center">
          <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center">
            <span className="text-xs font-medium">
              {getUserInitials(user?.username)}
            </span>
          </div>
          <div className="ml-3">
            <p className="text-sm font-medium">{user?.username || "Guest"}</p>
            <p className="text-xs text-muted-foreground">{user?.plan || "No Plan"}</p>
          </div>
          <button 
            className="ml-auto text-muted-foreground hover:text-foreground"
            onClick={handleLogout}
            aria-label="Logout"
          >
            <LogOut className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
