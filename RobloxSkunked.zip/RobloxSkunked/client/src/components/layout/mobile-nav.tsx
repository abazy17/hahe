import { Link, useLocation } from "wouter";
import { User } from "@/lib/types";
import { Menu, X, Code, UserCircle, Gamepad2, Terminal, Settings, LogOut, ShieldAlert } from "lucide-react";
import { useEffect } from "react";
import { useAuth } from "@/lib/authContext";

interface MobileNavProps {
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  user: User | null;
}

export function MobileNav({ isOpen, setIsOpen, user }: MobileNavProps) {
  const [location] = useLocation();
  const { logout, isAdmin } = useAuth();
  
  const navItems = [
    { 
      name: "Profile", 
      path: "/profile", 
      icon: <UserCircle className="mr-3 h-5 w-5" /> 
    },
    { 
      name: "Games", 
      path: "/games", 
      icon: <Gamepad2 className="mr-3 h-5 w-5" /> 
    },
    { 
      name: "Executor", 
      path: "/executor", 
      icon: <Terminal className="mr-3 h-5 w-5" /> 
    },
    { 
      name: "Settings", 
      path: "/settings", 
      icon: <Settings className="mr-3 h-5 w-5" /> 
    },
    ...(isAdmin ? [{ 
      name: "Admin", 
      path: "/admin", 
      icon: <ShieldAlert className="mr-3 h-5 w-5" /> 
    }] : [])
  ];
  
  // Close menu when location changes
  useEffect(() => {
    setIsOpen(false);
  }, [location, setIsOpen]);
  
  return (
    <>
      {/* Mobile Header */}
      <div className="md:hidden fixed top-0 left-0 right-0 bg-card border-b border-border z-10">
        <div className="px-4 py-3 flex items-center justify-between">
          <div className="flex items-center">
            <div className="h-8 w-8 rounded-md bg-primary flex items-center justify-center mr-2">
              <Code className="text-primary-foreground h-5 w-5" />
            </div>
            <h1 className="text-lg font-bold">Skunked</h1>
          </div>
          <button 
            onClick={() => setIsOpen(!isOpen)}
            className="text-muted-foreground hover:text-foreground"
          >
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div className={`md:hidden fixed inset-0 bg-background z-20 pt-16 transition-opacity duration-200 ${
        isOpen ? "opacity-100" : "opacity-0 pointer-events-none"
      }`}>
        <nav className="px-4 py-4">
          <div className="space-y-3">
            {navItems.map((item) => (
              <Link 
                key={item.path} 
                href={item.path}
              >
                <a 
                  className={`flex items-center px-3 py-3 w-full rounded-md transition-all ${
                    location === item.path 
                      ? "bg-primary text-primary-foreground font-medium" 
                      : "text-muted-foreground hover:bg-muted hover:text-foreground"
                  }`}
                >
                  {item.icon}
                  <span>{item.name}</span>
                </a>
              </Link>
            ))}
            
            {/* Logout button */}
            <button 
              onClick={logout}
              className="flex items-center px-3 py-3 w-full rounded-md transition-all text-muted-foreground hover:bg-muted hover:text-foreground"
            >
              <LogOut className="mr-3 h-5 w-5" />
              <span>Logout</span>
            </button>
          </div>
          
          {/* User info in mobile menu */}
          <div className="mt-6 pt-6 border-t border-border px-3">
            <div className="flex items-center">
              <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center">
                <span className="text-xs font-medium">
                  {user?.username ? user.username.substring(0, 2).toUpperCase() : "GU"}
                </span>
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium">{user?.username || "Guest"}</p>
                <p className="text-xs text-muted-foreground">{user?.plan || "No Plan"}</p>
              </div>
            </div>
          </div>
        </nav>
      </div>
    </>
  );
}
