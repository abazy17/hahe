import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { CodeEditor } from "@/components/ui/code-editor";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Trash2, Download } from "lucide-react";
import { Script, ScriptExecutionResponse } from "@/lib/types";
import { apiRequest } from "@/lib/queryClient";

export default function Executor() {
  const [consoleOutput, setConsoleOutput] = useState<string[]>([
    "> Connecting to game server...",
    "> Connection established",
    "> Serverside ready"
  ]);
  
  const queryClient = useQueryClient();
  
  // Fetch scripts from API
  const { data: scripts } = useQuery<Script[]>({
    queryKey: ['/api/scripts'],
  });
  
  // Execute script mutation
  const executeMutation = useMutation({
    mutationFn: async (code: string) => {
      const response = await apiRequest("POST", "/api/execute-script", { script: code });
      return response.json() as Promise<ScriptExecutionResponse>;
    },
    onSuccess: (data) => {
      setConsoleOutput(prev => [...prev, ...data.output]);
      // Refresh activities after execution
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
      queryClient.invalidateQueries({ queryKey: ['/api/user-stats'] });
    },
  });
  
  // Handle script execution
  const handleExecuteScript = (code: string) => {
    executeMutation.mutate(code);
  };
  
  // Clear console
  const handleClearConsole = () => {
    setConsoleOutput([]);
  };
  
  // Auto-scroll console to bottom when output changes
  useEffect(() => {
    const consoleElement = document.getElementById("console-output");
    if (consoleElement) {
      consoleElement.scrollTop = consoleElement.scrollHeight;
    }
  }, [consoleOutput]);
  
  // Load script from library
  const handleLoadScript = (script: Script) => {
    // This would typically open the script in the editor
    alert(`Loading script: ${script.name}`);
  };
  
  return (
    <div className="py-6">
      <h1 className="text-2xl font-bold mb-6">Script Executor</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Script Editor */}
        <div className="lg:col-span-2">
          <CodeEditor onExecute={handleExecuteScript} />
        </div>

        {/* Script Console & Library */}
        <div>
          {/* Console Output */}
          <Card className="mb-4">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle>Console</CardTitle>
                <Button 
                  variant="outline" 
                  size="icon" 
                  title="Clear console" 
                  onClick={handleClearConsole}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div 
                id="console-output"
                className="bg-[#0D1117] rounded-md p-3 h-48 overflow-y-auto font-mono text-xs"
              >
                {consoleOutput.map((line, index) => (
                  <div 
                    key={index} 
                    className={
                      line.includes("Error") || line.includes("Failed") 
                        ? "text-red-400" 
                        : line.includes("success") || line.includes("activated") 
                          ? "text-green-400" 
                          : "text-gray-400"
                    }
                  >
                    {line}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Script Library */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Script Library</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {scripts && scripts.length > 0 ? (
                  scripts.map(script => (
                    <div 
                      key={script.id} 
                      className="flex items-center justify-between py-2 px-3 bg-muted rounded-md"
                    >
                      <div>
                        <p className="text-sm font-medium">{script.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {script.isUniversal ? "Universal" : "Game Specific"}
                        </p>
                      </div>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        onClick={() => handleLoadScript(script)}
                      >
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                  ))
                ) : (
                  <div className="text-muted-foreground text-sm py-2">No scripts found</div>
                )}
                
                {/* Example scripts */}
                {!scripts || scripts.length === 0 && (
                  <>
                    <div className="flex items-center justify-between py-2 px-3 bg-muted rounded-md">
                      <div>
                        <p className="text-sm font-medium">Admin Commands</p>
                        <p className="text-xs text-muted-foreground">Universal</p>
                      </div>
                      <Button variant="ghost" size="icon">
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="flex items-center justify-between py-2 px-3 bg-muted rounded-md">
                      <div>
                        <p className="text-sm font-medium">Teleport Script</p>
                        <p className="text-xs text-muted-foreground">Brookhaven</p>
                      </div>
                      <Button variant="ghost" size="icon">
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="flex items-center justify-between py-2 px-3 bg-muted rounded-md">
                      <div>
                        <p className="text-sm font-medium">ESP Script</p>
                        <p className="text-xs text-muted-foreground">Universal</p>
                      </div>
                      <Button variant="ghost" size="icon">
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                  </>
                )}
                
                <Button 
                  variant="outline" 
                  className="w-full mt-2"
                >
                  Browse Script Hub
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
