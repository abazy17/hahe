import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { StatCard } from "@/components/ui/stat-card";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Calendar, 
  Timer, 
  FileCode, 
  Gamepad2, 
  Terminal, 
  FileCode2, 
  Copy, 
  Share2 
} from "lucide-react";
import { Activity, UserStats, User } from "@/lib/types";
import { formatDistanceToNow } from "date-fns";
import { useToast } from "@/hooks/use-toast";

export default function Profile() {
  const [showAffiliateLink, setShowAffiliateLink] = useState(false);
  const { toast } = useToast();
  
  // Fetch user data
  const { data: user } = useQuery<User>({
    queryKey: ['/api/users/current'],
  });
  
  // Fetch user stats
  const { data: stats } = useQuery<UserStats>({
    queryKey: ['/api/user-stats'],
  });
  
  // Fetch user activities
  const { data: activities } = useQuery<Activity[]>({
    queryKey: ['/api/activities'],
  });
  
  // Generate affiliation link
  const affiliateLink = user ? `https://skunked.lol/a/${user.username}` : "";
  
  const getUserInitials = (username?: string) => {
    if (!username) return "SK";
    
    const names = username.split(" ");
    if (names.length === 1) {
      return username.substring(0, 2).toUpperCase();
    }
    
    return `${names[0].charAt(0)}${names[1].charAt(0)}`.toUpperCase();
  };
  
  const getActivityIcon = (type: string) => {
    switch (type) {
      case "script_executed":
        return <Terminal className="text-muted-foreground" />;
      case "game_joined":
        return <Gamepad2 className="text-muted-foreground" />;
      case "script_saved":
        return <FileCode2 className="text-muted-foreground" />;
      default:
        return <FileCode className="text-muted-foreground" />;
    }
  };
  
  const formatDate = (dateString?: string) => {
    if (!dateString) return "";
    return formatDistanceToNow(new Date(dateString), { addSuffix: true });
  };
  
  const handleCopyAffiliateLink = () => {
    if (affiliateLink) {
      navigator.clipboard.writeText(affiliateLink);
      toast({
        title: "Affiliate link copied!",
        description: "Your affiliate link has been copied to clipboard."
      });
    }
  };
  
  return (
    <div className="py-6">
      <h1 className="text-2xl font-bold mb-6">Profile</h1>

      {/* User Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <StatCard 
          icon={<FileCode className="text-xl" />} 
          label="Scripts Executed" 
          value={stats?.scriptsExecuted || 0} 
        />
        <StatCard 
          icon={<Gamepad2 className="text-xl" />} 
          label="Games Played" 
          value={stats?.gamesPlayed || 0} 
          iconColor="text-blue-500" 
          iconBgColor="bg-blue-500/20" 
        />
        <StatCard 
          icon={<Timer className="text-xl" />} 
          label="Subscription" 
          value={`${stats?.subscriptionDays || 0} days`} 
          iconColor="text-green-500" 
          iconBgColor="bg-green-500/20" 
        />
      </div>

      {/* User Profile Card */}
      <Card className="mb-6">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row items-start md:items-center">
            <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center mr-4 mb-4 md:mb-0">
              <span className="text-lg font-medium">
                {getUserInitials(user?.username)}
              </span>
            </div>
            <div>
              <h2 className="text-xl font-semibold mb-1">{user?.username || "SkunkedUser"}</h2>
              <p className="text-muted-foreground mb-3">
                Member since {user?.createdAt ? new Date(user.createdAt).toLocaleDateString('en-US', { month: 'short', year: 'numeric' }) : "Jan 2023"}
              </p>
              <div className="flex items-center">
                <Badge variant="secondary" className="bg-primary/20 text-primary hover:bg-primary/30">
                  {user?.plan || "Premium Plan"}
                </Badge>
                <Badge variant="secondary" className="ml-2 bg-green-500/20 text-green-500 hover:bg-green-500/30">
                  Verified
                </Badge>
              </div>
            </div>
            <Button variant="outline" className="mt-4 md:mt-0 md:ml-auto">
              Edit Profile
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Affiliate Link */}
      <Card className="mb-6">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Your Affiliate Link</h2>
            <Button 
              variant="outline" 
              size="sm" 
              className="flex items-center mt-2 md:mt-0"
              onClick={() => setShowAffiliateLink(!showAffiliateLink)}
            >
              <Share2 className="mr-2 h-4 w-4" /> 
              {showAffiliateLink ? "Hide" : "Show"} Affiliate Link
            </Button>
          </div>
          
          {showAffiliateLink && (
            <div className="mt-2">
              <p className="text-sm text-muted-foreground mb-2">
                Share this link with your friends and earn rewards when they sign up!
              </p>
              <div className="flex gap-2">
                <Input 
                  readOnly 
                  value={affiliateLink} 
                  className="font-mono text-sm bg-muted"
                />
                <Button 
                  className="shrink-0" 
                  onClick={handleCopyAffiliateLink}
                  title="Copy to clipboard"
                >
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Recent Activity */}
      <Card>
        <CardContent className="p-6">
          <h2 className="text-lg font-semibold mb-4">Recent Activity</h2>
          <div className="space-y-4">
            {activities && activities.length > 0 ? (
              activities.map((activity) => (
                <div key={activity.id} className="flex items-start pb-4 border-b border-border">
                  <div className="h-8 w-8 rounded-md bg-muted flex items-center justify-center mr-3">
                    {getActivityIcon(activity.type)}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">{activity.details}</p>
                    <p className="text-xs text-muted-foreground">{formatDate(activity.createdAt)}</p>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-muted-foreground text-sm">No recent activity found.</div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
