import { useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/lib/authContext";
import { useToast } from "@/hooks/use-toast";
import { KeyRound, User } from "lucide-react";

export default function Auth() {
  const [activeTab, setActiveTab] = useState("register");
  const [username, setUsername] = useState("");
  const [key, setKey] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { login, register } = useAuth();
  const { toast } = useToast();
  const [_, setLocation] = useLocation(); // Using _ for unused variable

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    if (!username || !key) {
      toast({
        title: "Error",
        description: "Please enter both username and key",
        variant: "destructive",
      });
      setIsLoading(false);
      return;
    }
    
    try {
      const success = await register(username, key);
      if (success) {
        toast({
          title: "Registration Successful",
          description: "Welcome to Skunked Serverside!",
        });
        setLocation("/");
      } else {
        toast({
          title: "Registration Failed",
          description: "Invalid key or username already taken",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Registration Error",
        description: "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    if (!username || !key) {
      toast({
        title: "Error",
        description: "Please enter both username and key",
        variant: "destructive",
      });
      setIsLoading(false);
      return;
    }
    
    try {
      const success = await login(username, key);
      if (success) {
        toast({
          title: "Login Successful",
          description: "Welcome back to Skunked Serverside!",
        });
        setLocation("/");
      } else {
        toast({
          title: "Login Failed",
          description: "Invalid username or key",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Login Error",
        description: "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-primary mb-2">Skunked</h1>
          <p className="text-muted-foreground">Advanced Roblox Serverside</p>
        </div>
        <Card>
          <CardHeader>
            <CardTitle className="text-center">Welcome</CardTitle>
            <CardDescription className="text-center">
              {activeTab === "register"
                ? "Create an account to continue"
                : "Login to your account"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs
              defaultValue="register"
              value={activeTab}
              onValueChange={setActiveTab}
              className="w-full"
            >
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="register">Register</TabsTrigger>
                <TabsTrigger value="login">Login</TabsTrigger>
              </TabsList>
              <TabsContent value="register">
                <form onSubmit={handleRegister}>
                  <div className="space-y-4 mt-4">
                    <div className="space-y-2">
                      <Label htmlFor="register-username">Username</Label>
                      <div className="relative">
                        <User className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                        <Input
                          id="register-username"
                          placeholder="Enter your username"
                          className="pl-10"
                          value={username}
                          onChange={(e) => setUsername(e.target.value)}
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="register-key">Whitelist Key</Label>
                      <div className="relative">
                        <KeyRound className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                        <Input
                          id="register-key"
                          type="password"
                          placeholder="Enter your whitelist key"
                          className="pl-10"
                          value={key}
                          onChange={(e) => setKey(e.target.value)}
                        />
                      </div>
                    </div>
                    <Button type="submit" className="w-full" disabled={isLoading}>
                      {isLoading ? "Registering..." : "Register"}
                    </Button>
                  </div>
                </form>
              </TabsContent>
              <TabsContent value="login">
                <form onSubmit={handleLogin}>
                  <div className="space-y-4 mt-4">
                    <div className="space-y-2">
                      <Label htmlFor="login-username">Username</Label>
                      <div className="relative">
                        <User className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                        <Input
                          id="login-username"
                          placeholder="Enter your username"
                          className="pl-10"
                          value={username}
                          onChange={(e) => setUsername(e.target.value)}
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="login-key">Whitelist Key</Label>
                      <div className="relative">
                        <KeyRound className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                        <Input
                          id="login-key"
                          type="password"
                          placeholder="Enter your whitelist key"
                          className="pl-10"
                          value={key}
                          onChange={(e) => setKey(e.target.value)}
                        />
                      </div>
                    </div>
                    <Button type="submit" className="w-full" disabled={isLoading}>
                      {isLoading ? "Logging in..." : "Login"}
                    </Button>
                  </div>
                </form>
              </TabsContent>
            </Tabs>
          </CardContent>
          <CardFooter className="flex flex-col space-y-2">
            <div className="text-xs text-center text-muted-foreground">
              By continuing, you agree to our Terms of Service and Privacy Policy.
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}