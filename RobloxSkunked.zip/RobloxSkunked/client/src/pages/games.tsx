import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { GameCard } from "@/components/ui/game-card";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Search,
  User
} from "lucide-react";
import { Game } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";

export default function Games() {
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();
  
  // Fetch all games
  const { data: allGames = [] } = useQuery<Game[]>({
    queryKey: ['/api/games'],
  });
  
  // Fetch popular games
  const { data: popularGames = [] } = useQuery<Game[]>({
    queryKey: ['/api/games/popular'],
  });
  
  // Filter games based on search query
  const filteredGames = searchQuery 
    ? allGames.filter(game => 
        game.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        game.genre.toLowerCase().includes(searchQuery.toLowerCase()) ||
        game.description.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : allGames;
  
  // Recent games - mocked for now
  const recentGames = allGames.slice(0, 4);
  
  const handleJoinGame = (gameId: number) => {
    const game = allGames.find(g => g.id === gameId);
    
    if (game) {
      toast({
        title: "Joining game",
        description: `Connecting to ${game.name}...`
      });
    }
  };
  
  return (
    <div className="py-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 gap-4">
        <h1 className="text-2xl font-bold">Games</h1>

        <div className="relative w-full md:w-64">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search games..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      {/* Featured Games */}
      <h2 className="text-lg font-semibold mb-3">Featured Games</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {popularGames.map(game => (
          <GameCard
            key={game.id}
            game={game}
            onJoin={handleJoinGame}
          />
        ))}
      </div>

      {/* Recently Played */}
      <h2 className="text-lg font-semibold mb-3">Recently Played</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {recentGames.map(game => (
          <GameCard
            key={game.id}
            game={game}
            variant="small"
            onJoin={handleJoinGame}
            lastPlayed={Math.floor(Math.random() * 3) === 0 ? "2 hours ago" : "Yesterday"}
          />
        ))}
      </div>

      {/* All Games */}
      <h2 className="text-lg font-semibold mb-3">All Games</h2>
      <Card>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-border">
            <thead className="bg-muted">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Game</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Genre</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Players</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Status</th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-muted-foreground uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-card divide-y divide-border">
              {filteredGames.map(game => (
                <tr key={game.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="h-10 w-10 flex-shrink-0 rounded overflow-hidden">
                        <img className="h-10 w-10 object-cover" src={game.imageUrl} alt={game.name} />
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium">{game.name}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-muted-foreground">{game.genre}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm">{(game.activePlayers / 1000).toFixed(0)}K</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {game.isSupported ? (
                      <Badge variant="outline" className="bg-green-500/20 text-green-500 hover:bg-green-500/30 hover:text-green-500">
                        Supported
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="bg-amber-500/20 text-amber-500 hover:bg-amber-500/30 hover:text-amber-500">
                        Partial
                      </Badge>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <Button 
                      variant="link" 
                      className="text-blue-500 hover:text-blue-400"
                      onClick={() => handleJoinGame(game.id)}
                    >
                      Join
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
