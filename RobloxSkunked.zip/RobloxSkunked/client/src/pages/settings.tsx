import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { 
  Moon, 
  Sun, 
  UserCircle, 
  Upload, 
  Edit2, 
  Check, 
  Bell, 
  BellOff,
  KeyRound
} from "lucide-react";

export default function Settings() {
  const [activeSection, setActiveSection] = useState("general");
  const { toast } = useToast();
  
  const [settings, setSettings] = useState({
    // General settings
    autoAttach: true,
    autoExecute: true,
    fpsUnlocker: false,
    editorFontSize: 14,
    memoryLimit: "512mb",
    
    // Appearance settings
    theme: "dark",
    
    // Notification settings
    receiveNotifications: true,
    scriptCompletionNotifications: true,
    updateNotifications: true,
    securityNotifications: true,
    
    // Account settings
    robloxUsername: "SkunkedUser123",
    profilePictureUrl: "https://imagedelivery.net/95_mmzfqHEMHzYp4CX8eSg/6ccf034c-ec73-412e-6e02-7f68c178ca00/avatar",
    whitelistKey: "********************",
  });
  
  const updateSetting = (key: string, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
    
    // Show a toast notification when settings are updated
    toast({
      title: "Settings updated",
      description: "Your changes have been saved.",
    });
  };
  
  const sections = [
    { id: "general", name: "General" },
    { id: "appearance", name: "Appearance" },
    { id: "notifications", name: "Notifications" },
    { id: "account", name: "Account" },
    { id: "executor", name: "Executor" },
    { id: "about", name: "About" }
  ];
  
  const handleFileUpload = () => {
    // Simulating profile picture update
    updateSetting('profilePictureUrl', 'https://imagedelivery.net/95_mmzfqHEMHzYp4CX8eSg/7ae9c0f3-a36f-4a56-7f53-e50e5f42bf00/avatar');
    
    toast({
      title: "Profile picture updated",
      description: "Your new profile picture has been uploaded.",
    });
  };
  
  const updateWhitelistKey = () => {
    // Simulating whitelist key update
    updateSetting('whitelistKey', '*****************');
    
    toast({
      title: "Whitelist key updated",
      description: "Your whitelist has been updated successfully."
    });
  };
  
  return (
    <div className="py-6">
      <h1 className="text-2xl font-bold mb-6">Settings</h1>

      <Card className="overflow-hidden">
        <div className="grid grid-cols-1 md:grid-cols-4">
          {/* Settings Navigation */}
          <div className="border-r border-border">
            <nav className="p-4">
              <ul className="space-y-1">
                {sections.map(section => (
                  <li key={section.id}>
                    <button
                      onClick={() => setActiveSection(section.id)}
                      className={`block px-3 py-2 rounded-md w-full text-left ${
                        activeSection === section.id 
                          ? "bg-primary text-primary-foreground font-medium" 
                          : "text-muted-foreground hover:bg-muted hover:text-foreground"
                      }`}
                    >
                      {section.name}
                    </button>
                  </li>
                ))}
              </ul>
            </nav>
          </div>

          {/* Settings Content */}
          <div className="col-span-3 p-6">
            {/* General Settings */}
            {activeSection === "general" && (
              <div>
                <h2 className="text-lg font-semibold mb-4">General Settings</h2>
                
                {/* Auto-Attach */}
                <div className="py-4 border-b border-border">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium">Auto-Attach</h3>
                      <p className="text-sm text-muted-foreground mt-1">Automatically attach when joining games</p>
                    </div>
                    <Switch 
                      checked={settings.autoAttach} 
                      onCheckedChange={value => updateSetting('autoAttach', value)} 
                    />
                  </div>
                </div>
                
                {/* Auto-Execute */}
                <div className="py-4 border-b border-border">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium">Auto-Execute</h3>
                      <p className="text-sm text-muted-foreground mt-1">Run saved scripts automatically when joining games</p>
                    </div>
                    <Switch 
                      checked={settings.autoExecute} 
                      onCheckedChange={value => updateSetting('autoExecute', value)} 
                    />
                  </div>
                </div>
                
                {/* FPS Unlocker */}
                <div className="py-4 border-b border-border">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium">FPS Unlocker</h3>
                      <p className="text-sm text-muted-foreground mt-1">Unlock framerate limit in games</p>
                    </div>
                    <Switch 
                      checked={settings.fpsUnlocker} 
                      onCheckedChange={value => updateSetting('fpsUnlocker', value)} 
                    />
                  </div>
                </div>
                
                {/* Editor Font Size */}
                <div className="py-4 border-b border-border">
                  <div>
                    <h3 className="font-medium mb-2">Editor Font Size</h3>
                    <div className="flex items-center">
                      <span className="text-sm text-muted-foreground mr-3">12px</span>
                      <Slider
                        defaultValue={[settings.editorFontSize]}
                        min={10}
                        max={24}
                        step={1}
                        className="w-full"
                        onValueChange={([value]) => updateSetting('editorFontSize', value)}
                      />
                      <span className="text-sm text-muted-foreground ml-3">24px</span>
                    </div>
                  </div>
                </div>
                
                {/* Memory Usage Limit */}
                <div className="py-4">
                  <div>
                    <h3 className="font-medium mb-2">Memory Usage Limit</h3>
                    <Select 
                      value={settings.memoryLimit}
                      onValueChange={value => updateSetting('memoryLimit', value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select a memory limit" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="512mb">512 MB (Recommended)</SelectItem>
                        <SelectItem value="1gb">1 GB</SelectItem>
                        <SelectItem value="2gb">2 GB</SelectItem>
                        <SelectItem value="unlimited">Unlimited</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            )}
            
            {/* Appearance Settings */}
            {activeSection === "appearance" && (
              <div>
                <h2 className="text-lg font-semibold mb-4">Appearance Settings</h2>
                
                {/* Theme Selector */}
                <div className="py-4 border-b border-border">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium">Theme</h3>
                      <p className="text-sm text-muted-foreground mt-1">Choose between light and dark mode</p>
                    </div>
                    <div className="flex items-center space-x-4">
                      <button
                        onClick={() => updateSetting('theme', 'light')}
                        className={`p-2 rounded-md ${
                          settings.theme === 'light' 
                            ? 'bg-primary text-primary-foreground' 
                            : 'bg-muted text-muted-foreground'
                        }`}
                        aria-label="Light Mode"
                      >
                        <Sun className="h-5 w-5" />
                      </button>
                      <button
                        onClick={() => updateSetting('theme', 'dark')}
                        className={`p-2 rounded-md ${
                          settings.theme === 'dark' 
                            ? 'bg-primary text-primary-foreground' 
                            : 'bg-muted text-muted-foreground'
                        }`}
                        aria-label="Dark Mode"
                      >
                        <Moon className="h-5 w-5" />
                      </button>
                    </div>
                  </div>
                </div>
                
                {/* UI Density */}
                <div className="py-4 border-b border-border">
                  <div>
                    <h3 className="font-medium mb-2">UI Density</h3>
                    <p className="text-sm text-muted-foreground mb-3">Adjust spacing between UI elements</p>
                    <div className="flex items-center">
                      <span className="text-sm text-muted-foreground mr-3">Compact</span>
                      <Slider
                        defaultValue={[1]}
                        min={0}
                        max={2}
                        step={1}
                        className="w-full"
                      />
                      <span className="text-sm text-muted-foreground ml-3">Spacious</span>
                    </div>
                  </div>
                </div>
                
                {/* Accent Color */}
                <div className="py-4">
                  <h3 className="font-medium mb-3">Accent Color</h3>
                  <div className="grid grid-cols-5 gap-2">
                    {['#7c3aed', '#2563eb', '#16a34a', '#ea580c', '#dc2626'].map((color) => (
                      <button
                        key={color}
                        className="w-8 h-8 rounded-full"
                        style={{ backgroundColor: color }}
                        aria-label={`Set accent color to ${color}`}
                      />
                    ))}
                  </div>
                </div>
              </div>
            )}
            
            {/* Notifications Settings */}
            {activeSection === "notifications" && (
              <div>
                <h2 className="text-lg font-semibold mb-4">Notification Settings</h2>
                
                {/* Receive Notifications */}
                <div className="py-4 border-b border-border">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium">Receive Notifications</h3>
                      <p className="text-sm text-muted-foreground mt-1">Enable or disable all notifications</p>
                    </div>
                    <div className="flex items-center">
                      {settings.receiveNotifications ? (
                        <Bell className="h-5 w-5 mr-2 text-muted-foreground" />
                      ) : (
                        <BellOff className="h-5 w-5 mr-2 text-muted-foreground" />
                      )}
                      <Switch 
                        checked={settings.receiveNotifications} 
                        onCheckedChange={value => updateSetting('receiveNotifications', value)} 
                      />
                    </div>
                  </div>
                </div>
                
                {/* Notification Types */}
                <div className="py-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium">Script Completion</h3>
                      <p className="text-sm text-muted-foreground mt-1">Get notified when scripts finish executing</p>
                    </div>
                    <Switch 
                      checked={settings.scriptCompletionNotifications} 
                      onCheckedChange={value => updateSetting('scriptCompletionNotifications', value)}
                      disabled={!settings.receiveNotifications}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium">Updates</h3>
                      <p className="text-sm text-muted-foreground mt-1">Receive updates about new features and patches</p>
                    </div>
                    <Switch 
                      checked={settings.updateNotifications} 
                      onCheckedChange={value => updateSetting('updateNotifications', value)}
                      disabled={!settings.receiveNotifications}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium">Security Alerts</h3>
                      <p className="text-sm text-muted-foreground mt-1">Get important security notifications</p>
                    </div>
                    <Switch 
                      checked={settings.securityNotifications} 
                      onCheckedChange={value => updateSetting('securityNotifications', value)}
                      disabled={!settings.receiveNotifications}
                    />
                  </div>
                </div>
              </div>
            )}
            
            {/* Account Settings */}
            {activeSection === "account" && (
              <div>
                <h2 className="text-lg font-semibold mb-4">Account Settings</h2>
                
                {/* Roblox Username */}
                <div className="py-4 border-b border-border">
                  <div>
                    <h3 className="font-medium mb-2">Roblox Username</h3>
                    <div className="flex items-center">
                      <Input 
                        value={settings.robloxUsername} 
                        onChange={(e) => setSettings(prev => ({ ...prev, robloxUsername: e.target.value }))}
                        className="max-w-md"
                      />
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="ml-2"
                        onClick={() => updateSetting('robloxUsername', settings.robloxUsername)}
                      >
                        <Check className="h-4 w-4 mr-1" /> Update
                      </Button>
                    </div>
                  </div>
                </div>
                
                {/* Profile Picture */}
                <div className="py-4 border-b border-border">
                  <div>
                    <h3 className="font-medium mb-2">Profile Picture</h3>
                    <div className="flex items-center">
                      <div className="mr-4">
                        <div className="w-20 h-20 rounded-full overflow-hidden">
                          <img 
                            src={settings.profilePictureUrl} 
                            alt="Profile" 
                            className="w-full h-full object-cover"
                          />
                        </div>
                      </div>
                      <Button 
                        variant="outline" 
                        className="flex items-center"
                        onClick={handleFileUpload}
                      >
                        <Upload className="h-4 w-4 mr-2" /> Upload new picture
                      </Button>
                    </div>
                  </div>
                </div>
                
                {/* Whitelist Key */}
                <div className="py-4">
                  <div>
                    <h3 className="font-medium mb-2">Whitelist Key</h3>
                    <p className="text-sm text-muted-foreground mb-3">Update your whitelist key to maintain access</p>
                    <div className="flex items-center">
                      <Input 
                        type="password" 
                        className="max-w-md"
                        placeholder="Enter new whitelist key"
                      />
                      <Button 
                        variant="secondary" 
                        className="ml-2"
                        onClick={updateWhitelistKey}
                      >
                        <KeyRound className="h-4 w-4 mr-2" /> Update Key
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            {/* Executor Settings */}
            {activeSection === "executor" && (
              <div>
                <h2 className="text-lg font-semibold mb-4">Executor Settings</h2>
                
                {/* Script Execution */}
                <div className="py-4 border-b border-border">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium">Safe Mode</h3>
                      <p className="text-sm text-muted-foreground mt-1">Run scripts in a sandboxed environment</p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                </div>
                
                {/* Script Auto-Save */}
                <div className="py-4 border-b border-border">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium">Auto-Save Scripts</h3>
                      <p className="text-sm text-muted-foreground mt-1">Automatically save script changes</p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                </div>
                
                {/* Script Execution Timeout */}
                <div className="py-4">
                  <div>
                    <h3 className="font-medium mb-2">Script Timeout (seconds)</h3>
                    <div className="flex items-center">
                      <span className="text-sm text-muted-foreground mr-3">5s</span>
                      <Slider
                        defaultValue={[30]}
                        min={5}
                        max={60}
                        step={5}
                        className="w-full"
                      />
                      <span className="text-sm text-muted-foreground ml-3">60s</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            {/* About Section */}
            {activeSection === "about" && (
              <div>
                <h2 className="text-lg font-semibold mb-4">About Skunked</h2>
                
                <div className="py-4 mb-6 space-y-4">
                  <p>
                    Skunked Serverside is a powerful Roblox script execution platform that provides
                    seamless integration with popular Roblox games. Our serverside technology allows
                    for enhanced script execution capabilities that client-side executors cannot match.
                  </p>
                  <p>
                    With Skunked, you can create, save, and execute Lua scripts across multiple games,
                    customize your experience with our feature-rich editor, and enjoy premium benefits
                    like FPS unlockers, teleportation, and admin commands.
                  </p>
                  <p>
                    Our platform is constantly evolving with new game support and features being added
                    regularly. Join the growing community of Skunked users and elevate your Roblox experience.
                  </p>
                </div>
                
                <div className="bg-muted p-4 rounded-md">
                  <h3 className="font-medium mb-2">Version Information</h3>
                  <div className="text-sm">
                    <div className="flex justify-between py-1">
                      <span>Product Version:</span>
                      <span className="font-mono">1.2.5</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span>API Version:</span>
                      <span className="font-mono">3.4.1</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span>Last Updated:</span>
                      <span className="font-mono">March 28, 2025</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </Card>
    </div>
  );
}
