import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { User, AdminLog } from "@/lib/types";
import { useAuth } from "@/lib/authContext";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertTriangle, CheckCircle, Shield, User as UserIcon, Clock, Activity } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

export default function AdminPage() {
  const { isAdmin, user } = useAuth();
  const { toast } = useToast();
  const [actionReason, setActionReason] = useState("");
  const [selectedRole, setSelectedRole] = useState<string>("user");
  
  // User management state
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);

  // Fetch all users
  const { data: users, isLoading: usersLoading, refetch: refetchUsers } = useQuery<User[]>({
    queryKey: ['/api/admin/users'],
    enabled: isAdmin,
  });
  
  // Fetch admin logs
  const { data: logs, isLoading: logsLoading, refetch: refetchLogs } = useQuery<AdminLog[]>({
    queryKey: ['/api/admin/logs'],
    enabled: isAdmin,
  });

  // Fetch logs specific to this admin
  const { data: myLogs, isLoading: myLogsLoading } = useQuery<AdminLog[]>({
    queryKey: ['/api/admin/logs/by-admin'],
    enabled: isAdmin && !!user?.id,
  });

  if (!isAdmin) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-4rem)]">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-center">Access Denied</CardTitle>
            <CardDescription className="text-center">
              You don't have permission to access the admin panel.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center">
            <Shield className="text-red-500 h-16 w-16" />
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleBlacklist = async (userId: number) => {
    if (!actionReason.trim()) {
      toast({
        title: "Error",
        description: "Please provide a reason for blacklisting",
        variant: "destructive",
      });
      return;
    }

    try {
      await apiRequest(`/api/admin/users/${userId}/blacklist`, "POST", {
        reason: actionReason,
        ip: "127.0.0.1" // In a real app, this might be obtained differently
      });
      
      toast({
        title: "User Blacklisted",
        description: "User has been successfully blacklisted",
      });
      
      setActionReason("");
      refetchUsers();
      refetchLogs();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to blacklist user",
        variant: "destructive",
      });
    }
  };

  const handleWhitelist = async (userId: number) => {
    if (!actionReason.trim()) {
      toast({
        title: "Error",
        description: "Please provide a reason for whitelisting",
        variant: "destructive",
      });
      return;
    }

    try {
      await apiRequest(`/api/admin/users/${userId}/whitelist`, "POST", {
        reason: actionReason
      });
      
      toast({
        title: "User Whitelisted",
        description: "User has been successfully whitelisted",
      });
      
      setActionReason("");
      refetchUsers();
      refetchLogs();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to whitelist user",
        variant: "destructive",
      });
    }
  };

  const handleChangeRole = async (userId: number) => {
    try {
      await apiRequest(`/api/admin/users/${userId}/role`, "POST", {
        role: selectedRole
      });
      
      toast({
        title: "Role Updated",
        description: `User role has been changed to ${selectedRole}`,
      });
      
      refetchUsers();
      refetchLogs();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update user role",
        variant: "destructive",
      });
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString();
  };

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Admin Dashboard</h1>
      
      <Tabs defaultValue="users">
        <TabsList className="mb-6">
          <TabsTrigger value="users">User Management</TabsTrigger>
          <TabsTrigger value="logs">Admin Logs</TabsTrigger>
          <TabsTrigger value="my-actions">My Actions</TabsTrigger>
        </TabsList>
        
        {/* Users Tab */}
        <TabsContent value="users">
          <Card>
            <CardHeader>
              <CardTitle>User Management</CardTitle>
              <CardDescription>
                Manage all users in the system. You can blacklist/whitelist users or change their roles.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {usersLoading ? (
                <div className="flex justify-center py-8">Loading users...</div>
              ) : (
                <div className="space-y-6">
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>Username</TableHead>
                          <TableHead>Plan</TableHead>
                          <TableHead>Role</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Last Login</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {users?.map((user: User) => (
                          <TableRow key={user.id}>
                            <TableCell>{user.id}</TableCell>
                            <TableCell>{user.username}</TableCell>
                            <TableCell>{user.plan}</TableCell>
                            <TableCell>
                              <Badge variant={user.role === 'superadmin' ? 'destructive' : user.role === 'admin' ? 'default' : 'outline'}>
                                {user.role}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              {user.isBlacklisted ? (
                                <Badge variant="destructive" className="flex items-center gap-1">
                                  <AlertTriangle className="h-3 w-3" />
                                  Blacklisted
                                </Badge>
                              ) : (
                                <Badge variant="outline" className="flex items-center gap-1 bg-green-500 text-white">
                                  <CheckCircle className="h-3 w-3" />
                                  Active
                                </Badge>
                              )}
                            </TableCell>
                            <TableCell>
                              {user.lastLogin ? formatDate(user.lastLogin) : 'Never'}
                            </TableCell>
                            <TableCell>
                              <Button 
                                variant="outline" 
                                size="sm"
                                onClick={() => setSelectedUserId(user.id)}
                              >
                                Manage
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                  
                  {selectedUserId && (
                    <Card className="border-dashed">
                      <CardHeader>
                        <CardTitle className="text-lg">
                          User Actions - ID: {selectedUserId}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-4">
                            <h3 className="font-medium">Status Management</h3>
                            <div className="space-y-2">
                              <Input
                                placeholder="Reason for action"
                                value={actionReason}
                                onChange={(e) => setActionReason(e.target.value)}
                              />
                              <div className="flex gap-2">
                                <Button 
                                  variant="destructive" 
                                  onClick={() => handleBlacklist(selectedUserId)}
                                >
                                  Blacklist User
                                </Button>
                                <Button 
                                  variant="outline" 
                                  onClick={() => handleWhitelist(selectedUserId)}
                                >
                                  Whitelist User
                                </Button>
                              </div>
                            </div>
                          </div>
                          
                          <div className="space-y-4">
                            <h3 className="font-medium">Role Management</h3>
                            <div className="space-y-2">
                              <Select onValueChange={setSelectedRole} defaultValue="user">
                                <SelectTrigger>
                                  <SelectValue placeholder="Select a role" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="user">User</SelectItem>
                                  <SelectItem value="admin">Admin</SelectItem>
                                  <SelectItem value="superadmin">Super Admin</SelectItem>
                                </SelectContent>
                              </Select>
                              <Button 
                                onClick={() => handleChangeRole(selectedUserId)}
                              >
                                Change Role
                              </Button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Admin Logs Tab */}
        <TabsContent value="logs">
          <Card>
            <CardHeader>
              <CardTitle>Admin Activity Logs</CardTitle>
              <CardDescription>
                All administrative actions performed in the system
              </CardDescription>
            </CardHeader>
            <CardContent>
              {logsLoading ? (
                <div className="flex justify-center py-8">Loading logs...</div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>Admin</TableHead>
                        <TableHead>Action</TableHead>
                        <TableHead>Target User</TableHead>
                        <TableHead>Details</TableHead>
                        <TableHead>IP</TableHead>
                        <TableHead>Timestamp</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {logs?.map((log: AdminLog) => (
                        <TableRow key={log.id}>
                          <TableCell>{log.id}</TableCell>
                          <TableCell>{log.adminId}</TableCell>
                          <TableCell>
                            <Badge className="whitespace-nowrap">
                              {log.action}
                            </Badge>
                          </TableCell>
                          <TableCell>{log.targetUserId}</TableCell>
                          <TableCell className="max-w-xs truncate">
                            {log.details}
                          </TableCell>
                          <TableCell>{log.ip || 'N/A'}</TableCell>
                          <TableCell className="whitespace-nowrap">
                            {formatDate(log.createdAt)}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* My Actions Tab */}
        <TabsContent value="my-actions">
          <Card>
            <CardHeader>
              <CardTitle>My Admin Actions</CardTitle>
              <CardDescription>
                Administrative actions performed by you
              </CardDescription>
            </CardHeader>
            <CardContent>
              {myLogsLoading ? (
                <div className="flex justify-center py-8">Loading your activity...</div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>Action</TableHead>
                        <TableHead>Target User</TableHead>
                        <TableHead>Details</TableHead>
                        <TableHead>Timestamp</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {myLogs?.length ? (
                        myLogs.map((log: AdminLog) => (
                          <TableRow key={log.id}>
                            <TableCell>{log.id}</TableCell>
                            <TableCell>
                              <Badge>{log.action}</Badge>
                            </TableCell>
                            <TableCell>{log.targetUserId}</TableCell>
                            <TableCell className="max-w-xs truncate">
                              {log.details}
                            </TableCell>
                            <TableCell className="whitespace-nowrap">
                              {formatDate(log.createdAt)}
                            </TableCell>
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell colSpan={5} className="text-center py-4">
                            No admin actions recorded yet
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}