import { useState, useEffect } from "react";
import { Switch, Route, useLocation } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import { Sidebar } from "@/components/layout/sidebar";
import { MobileNav } from "@/components/layout/mobile-nav";
import Profile from "@/pages/profile";
import Games from "@/pages/games";
import Executor from "@/pages/executor";
import Settings from "@/pages/settings";
import AdminPage from "@/pages/admin";
import NotFound from "@/pages/not-found";
import Auth from "@/pages/auth";
import { AuthProvider, useAuth } from "@/lib/authContext";

function Router() {
  const [location, setLocation] = useLocation();
  const { isAuthenticated } = useAuth();
  
  // Handle the root path
  useEffect(() => {
    if (location === "/" && isAuthenticated) {
      setLocation("/profile");
    }
  }, [location, setLocation, isAuthenticated]);
  
  // If user is not authenticated, only show auth page
  if (!isAuthenticated) {
    return (
      <Switch>
        <Route path="/auth" component={Auth} />
        <Route>
          {() => {
            // Redirect any other path to auth
            setLocation("/auth");
            return null;
          }}
        </Route>
      </Switch>
    );
  }
  
  // For authenticated users, show all routes
  return (
    <Switch>
      <Route path="/profile" component={Profile} />
      <Route path="/games" component={Games} />
      <Route path="/executor" component={Executor} />
      <Route path="/settings" component={Settings} />
      <Route path="/admin" component={AdminPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function AppContent() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user, isAuthenticated, isLoading } = useAuth();
  
  // Show loading state while checking authentication
  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center bg-background">
        <div className="animate-pulse text-center">
          <h1 className="text-2xl font-bold mb-4">Skunked</h1>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }
  
  // If not authenticated, show the auth page in full screen
  if (!isAuthenticated) {
    return (
      <div className="h-screen bg-background">
        <Router />
        <Toaster />
      </div>
    );
  }
  
  // Main application UI for authenticated users
  return (
    <div className="flex h-screen overflow-hidden bg-background text-foreground">
      {/* Sidebar for desktop */}
      <Sidebar user={user} />
      
      {/* Main content area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Mobile navigation header */}
        <MobileNav 
          isOpen={mobileMenuOpen} 
          setIsOpen={setMobileMenuOpen} 
          user={user}
        />
        
        {/* Main content */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6 md:pt-0 mt-16 md:mt-0">
          <Router />
        </main>
      </div>
      
      <Toaster />
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
