export interface User {
  id: number;
  username: string;
  plan: string;
  role: string;
  isBlacklisted?: boolean;
  ip?: string | null;
  country?: string | null;
  hwid?: string | null;
  lastLogin?: string | null;
  createdAt: string;
}

export interface Game {
  id: number;
  name: string;
  description: string;
  genre: string;
  imageUrl: string;
  activePlayers: number;
  isPopular: boolean;
  isSupported: boolean;
}

export interface Script {
  id: number;
  userId: number;
  name: string;
  content: string;
  gameId: number | null;
  isUniversal: boolean;
  createdAt: string;
}

export interface Activity {
  id: number;
  userId: number;
  type: string;
  details: string;
  gameId: number | null;
  createdAt: string;
}

export interface UserStats {
  id: number;
  userId: number;
  scriptsExecuted: number;
  gamesPlayed: number;
  subscriptionDays: number;
}

export interface ScriptExecutionResponse {
  success: boolean;
  message: string;
  output: string[];
}

export interface AdminLog {
  id: number;
  adminId: number;
  action: string;
  targetUserId: number;
  details: string;
  ip?: string | null;
  createdAt: string;
}
