import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  plan: text("plan").default("free"),
  role: text("role").default("user"),
  isBlacklisted: boolean("is_blacklisted").default(false),
  ip: text("ip"),
  country: text("country"),
  hwid: text("hwid"),
  lastLogin: timestamp("last_login"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const games = pgTable("games", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  genre: text("genre").notNull(),
  imageUrl: text("image_url").notNull(),
  activePlayers: integer("active_players").default(0),
  isPopular: boolean("is_popular").default(false),
  isSupported: boolean("is_supported").default(true),
});

export const scripts = pgTable("scripts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  name: text("name").notNull(),
  content: text("content").notNull(),
  gameId: integer("game_id").references(() => games.id),
  isUniversal: boolean("is_universal").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  type: text("type").notNull(), // script_executed, game_joined, script_saved
  details: text("details").notNull(),
  gameId: integer("game_id").references(() => games.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const userStats = pgTable("user_stats", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  scriptsExecuted: integer("scripts_executed").default(0),
  gamesPlayed: integer("games_played").default(0),
  subscriptionDays: integer("subscription_days").default(0),
});

export const adminLogs = pgTable("admin_logs", {
  id: serial("id").primaryKey(),
  adminId: integer("admin_id").references(() => users.id).notNull(),
  action: text("action").notNull(), // blacklist, whitelist, key_change, role_change
  targetUserId: integer("target_user_id").references(() => users.id),
  details: text("details").notNull(),
  ip: text("ip"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  plan: true,
});

export const insertGameSchema = createInsertSchema(games).omit({
  id: true,
});

export const insertScriptSchema = createInsertSchema(scripts).omit({
  id: true,
  createdAt: true,
});

export const insertActivitySchema = createInsertSchema(activities).omit({
  id: true,
  createdAt: true,
});

export const insertUserStatsSchema = createInsertSchema(userStats).omit({
  id: true,
});

export const insertAdminLogSchema = createInsertSchema(adminLogs).omit({
  id: true,
  createdAt: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertGame = z.infer<typeof insertGameSchema>;
export type InsertScript = z.infer<typeof insertScriptSchema>;
export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type InsertUserStats = z.infer<typeof insertUserStatsSchema>;
export type InsertAdminLog = z.infer<typeof insertAdminLogSchema>;

export type User = typeof users.$inferSelect;
export type Game = typeof games.$inferSelect;
export type Script = typeof scripts.$inferSelect;
export type Activity = typeof activities.$inferSelect;
export type UserStats = typeof userStats.$inferSelect;
export type AdminLog = typeof adminLogs.$inferSelect;
